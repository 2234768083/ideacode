package nuc.edu.cn.chapter05_mybatis1_2113042727;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter05Mybatis12113042727ApplicationTests {

    @Test
    void contextLoads() {
    }

}
