package nuc.edu.cn.chapter05_mybatis1_2113042727.pojo;
import nuc.edu.cn.chapter05_mybatis1_2113042727.pojo.Teacher;
import java.util.List;

public class MyClass {
    private int id;
    private String name;
    private Teacher teacher;
/***setter,getter方法***/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
}

