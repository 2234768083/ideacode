package nuc.edu.cn.chapter05_mybatis1_2113042727.service;

import nuc.edu.cn.chapter05_mybatis1_2113042727.pojo.MyClass;

public interface IMyClassService {
    public MyClass getMyClass(Integer id) ;
    public MyClass getMyClass2(Integer id) ;
}
