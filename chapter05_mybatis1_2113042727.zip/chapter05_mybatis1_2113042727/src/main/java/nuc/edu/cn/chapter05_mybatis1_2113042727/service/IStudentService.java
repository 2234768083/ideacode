package nuc.edu.cn.chapter05_mybatis1_2113042727.service;

import nuc.edu.cn.chapter05_mybatis1_2113042727.pojo.Student;

public interface IStudentService {
    public Student findById(Integer id);
}