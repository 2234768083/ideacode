package nuc.edu.cn.chapter05_mybatis1_2113042727.dao;

import nuc.edu.cn.chapter05_mybatis1_2113042727.pojo.Role;

public interface IRoleDao {
    public Role findById(Integer id);
}