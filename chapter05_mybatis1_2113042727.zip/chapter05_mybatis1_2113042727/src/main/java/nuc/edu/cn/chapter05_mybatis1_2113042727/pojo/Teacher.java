package nuc.edu.cn.chapter05_mybatis1_2113042727.pojo;

public class Teacher {
    private int id;
    private String name;
    /***setter,getter方法***/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

