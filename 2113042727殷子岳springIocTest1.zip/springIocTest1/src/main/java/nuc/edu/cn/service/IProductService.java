package nuc.edu.cn.service;

public interface IProductService {
    public void browse(String loginName, String productName);
}
