package nuc.edu.cn.dao;

public interface IUserDao {
    public void saveUser(String uname);
}
