package nuc.edu.cn.service;

public interface IUserService {
    public void saveUser(String uname);
}
