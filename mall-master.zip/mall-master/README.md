# mall

## sql
在sql目录下

## vue
```
cd vue
npm i 
npm run serve
```

## springboot
导入maven依赖，配置数据库，启动即可

## 访问
后台：http://localhost:8080
前台：http://localhost:8080/front/home

