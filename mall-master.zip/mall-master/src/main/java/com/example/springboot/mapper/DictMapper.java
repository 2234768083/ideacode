package com.example.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.springboot.entity.Dict;

public interface DictMapper extends BaseMapper<Dict> {
}
