package com.example.springboot.common;

public enum RoleEnum {
    ROLE_ADMIN, ROLE_USER;
}
