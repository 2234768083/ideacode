package com.example.springboot.utils;

import lombok.Data;

@Data
class TableColumn {
    private String name;
    private String comment;
}
